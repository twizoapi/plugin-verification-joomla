<?php
define('SECRET', 'OC5q7sbENSVcy20-MGlyuuxqwYNidpz-LmpL-Z0PYy9VEmVl');
define('API_HOST', 'api-asia-01.twizo.com');
